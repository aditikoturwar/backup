package com.example.aditik.spinnerfragment;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    FragmentTwo fragmentTwo;
    FragmentOne  fragmentOne;
    Spinner spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner =findViewById(R.id.spinner);
        fragmentOne=new FragmentOne();
        fragmentTwo=new FragmentTwo();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this, R.layout.custom_spinner,
                getResources().getStringArray(R.array.fragments));

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // attaching data adapter to spinner
        spinner.setAdapter(adapter);
    }

    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String selectedClass = parent.getItemAtPosition(position).toString();
        switch (selectedClass){
            case "0":
                setFragment(fragmentOne);
                break;

            case "1":
                setFragment(fragmentTwo);
                break;
        }
        }

public void setFragment(Fragment fragment){
    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
    fragmentTransaction.replace(R.id.main_frame,fragment);
    fragmentTransaction.commit();
}
}
